# ImageTool
Grab Bitmaps, Sprites, Bobs, edit the palette, and export all!
